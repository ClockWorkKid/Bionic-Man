#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDD_ABOUTBOX                            103
#define IDM_ABOUT                               104
#define IDM_EXIT                                105
#define IDM_SETTINGS							106
#define IDD_SETTINGSBOX							300
#define IDD_INTERVAL_SLIDER						301
#define IDD_INTERVAL_TEXT						302
#define IDI_ALGOSDKSAMPLE                       107
#define IDI_SMALL                               108
#define IDC_ALGOSDKSAMPLE                       109
#define IDD_INIT_BUTTON							110
#define IDD_START_BUTTON						111
#define IDD_STOP_BUTTON							112
#define IDD_BULK_DATA_BUTTON					113
#define IDD_AP_CHECK							114
#define IDD_ME_CHECK							115
#define IDD_ME2_CHECK							116
#define IDD_F_CHECK								117
#define IDD_F2_CHECK							118
#define IDD_ATT_CHECK							119
#define IDD_MED_CHECK							120
#define IDD_BP_CHECK							121
#define IDD_STATE_TEXT							211
#define IDD_SIGNAL_TEXT							212
#define IDD_OUTPUT_TEXT							213
#define IDS_APP_TITLE                           40000
